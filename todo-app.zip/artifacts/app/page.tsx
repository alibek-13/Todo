'use client';

import React, { useState, useEffect } from 'react';

interface Todo {
  id: number;
  text: string;
  completed: boolean;
}

export default function TodoApp() {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [filter, setFilter] = useState<'all' | 'active' | 'completed'>('all');

  // Load from localStorage
  useEffect(() => {
    const savedTodos = localStorage.getItem('todos');
    if (savedTodos) {
      setTodos(JSON.parse(savedTodos));
    }
  }, []);

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem('todos', JSON.stringify(todos));
  }, [todos]);

  const addTodo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const newTodo: Todo = {
      id: Date.now(),
      text: inputValue.trim(),
      completed: false,
    };

    setTodos([...todos, newTodo]);
    setInputValue('');
  };

  const toggleTodo = (id: number) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    ));
  };

  const deleteTodo = (id: number) => {
    setTodos(todos.filter(todo => todo.id !== id));
  };

  const editTodo = (id: number, newText: string) => {
    if (!newText.trim()) return;
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, text: newText.trim() } : todo
    ));
  };

  const clearCompleted = () => {
    setTodos(todos.filter(todo => !todo.completed));
  };

  const filteredTodos = todos.filter(todo => {
    if (filter === 'active') return !todo.completed;
    if (filter === 'completed') return todo.completed;
    return true;
  });

  const activeCount = todos.filter(todo => !todo.completed).length;

  return (
    <div className="min-h-screen bg-zinc-50 dark:bg-zinc-950 flex items-center justify-center p-4 font-sans">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <h1 className="text-6xl font-bold text-zinc-900 dark:text-white tracking-tighter mb-2">todos</h1>
          <p className="text-zinc-500 dark:text-zinc-400">Simple and beautiful todo app</p>
        </div>

        <div className="bg-white dark:bg-zinc-900 rounded-2xl shadow-xl overflow-hidden border border-zinc-200 dark:border-zinc-800">
          {/* Add new todo */}
          <form onSubmit={addTodo} className="p-6 border-b border-zinc-200 dark:border-zinc-800">
            <div className="flex gap-3">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="What needs to be done?"
                className="flex-1 px-5 py-4 bg-zinc-100 dark:bg-zinc-800 rounded-xl text-lg focus:outline-none focus:ring-2 focus:ring-black dark:focus:ring-white placeholder:text-zinc-400"
                autoFocus
              />
              <button
                type="submit"
                className="px-8 py-4 bg-black dark:bg-white text-white dark:text-black rounded-xl font-medium hover:bg-zinc-800 dark:hover:bg-zinc-200 transition-colors"
              >
                Add
              </button>
            </div>
          </form>

          {/* Todo list */}
          <div className="max-h-[420px] overflow-auto">
            {filteredTodos.length === 0 ? (
              <div className="p-12 text-center text-zinc-400 dark:text-zinc-500">
                {filter === 'all' ? "No todos yet. Add one above!" : `No ${filter} todos`}
              </div>
            ) : (
              <ul className="divide-y divide-zinc-200 dark:divide-zinc-800">
                {filteredTodos.map((todo) => (
                  <li key={todo.id} className="flex items-center gap-4 px-6 py-4 group">
                    <button
                      onClick={() => toggleTodo(todo.id)}
                      className={`w-6 h-6 rounded-full border-2 flex-shrink-0 flex items-center justify-center transition-all ${
                        todo.completed 
                          ? 'bg-black dark:bg-white border-black dark:border-white' 
                          : 'border-zinc-300 dark:border-zinc-600 hover:border-zinc-400'
                      }`}
                    >
                      {todo.completed && <span className="text-white dark:text-black text-xl leading-none">✓</span>}
                    </button>

                    <input
                      type="text"
                      value={todo.text}
                      onChange={(e) => editTodo(todo.id, e.target.value)}
                      onBlur={(e) => editTodo(todo.id, e.target.value)}
                      className={`flex-1 bg-transparent text-lg focus:outline-none ${
                        todo.completed ? 'line-through text-zinc-400 dark:text-zinc-500' : ''
                      }`}
                    />

                    <button
                      onClick={() => deleteTodo(todo.id)}
                      className="opacity-0 group-hover:opacity-100 text-red-500 hover:text-red-600 transition-all p-1"
                    >
                      ✕
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Footer */}
          {todos.length > 0 && (
            <div className="flex items-center justify-between px-6 py-4 text-sm text-zinc-500 border-t border-zinc-200 dark:border-zinc-800">
              <div>{activeCount} {activeCount === 1 ? 'item' : 'items'} left</div>
              
              <div className="flex gap-1">
                <button
                  onClick={() => setFilter('all')}
                  className={`px-3 py-1 rounded-lg transition-colors ${filter === 'all' ? 'bg-zinc-200 dark:bg-zinc-800 text-black dark:text-white' : 'hover:bg-zinc-100 dark:hover:bg-zinc-800'}`}
                >
                  All
                </button>
                <button
                  onClick={() => setFilter('active')}
                  className={`px-3 py-1 rounded-lg transition-colors ${filter === 'active' ? 'bg-zinc-200 dark:bg-zinc-800 text-black dark:text-white' : 'hover:bg-zinc-100 dark:hover:bg-zinc-800'}`}
                >
                  Active
                </button>
                <button
                  onClick={() => setFilter('completed')}
                  className={`px-3 py-1 rounded-lg transition-colors ${filter === 'completed' ? 'bg-zinc-200 dark:bg-zinc-800 text-black dark:text-white' : 'hover:bg-zinc-100 dark:hover:bg-zinc-800'}`}
                >
                  Completed
                </button>
              </div>

              <button
                onClick={clearCompleted}
                className="hover:text-red-500 transition-colors"
                disabled={todos.filter(t => t.completed).length === 0}
              >
                Clear completed
              </button>
            </div>
          )}
        </div>

        <div className="mt-8 text-center text-xs text-zinc-400 dark:text-zinc-500">
          Double-click a todo to edit • Data saved in browser
        </div>
      </div>
    </div>
  );
}
